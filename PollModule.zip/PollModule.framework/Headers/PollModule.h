//
//  PollModule.h
//  PollModule
//
//  Created by Yogev Barber on 06/03/2018.
//  Copyright © 2018 IBand. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PollModule.
FOUNDATION_EXPORT double PollModuleVersionNumber;

//! Project version string for PollModule.
FOUNDATION_EXPORT const unsigned char PollModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PollModule/PublicHeader.h>
#import <PollModule/IBandPoll.h>
#import <PollModule/IBandPollQuestion.h>

