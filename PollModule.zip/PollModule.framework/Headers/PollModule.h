//
//  PollModule.h
//  PollModule
//
//  Created by Yogev Barber on 27/02/2018.
//  Copyright © 2018 IBand. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PollModule.
FOUNDATION_EXPORT double PollModuleVersionNumber;

//! Project version string for PollModule.
FOUNDATION_EXPORT const unsigned char PollModuleVersionString[];

#import <PollModule-iOS/IBandPoll.h>
#import <PollModule-iOS/IBandPollQuestion.h>

