//
//  IBandPoll+Internal.h
//  IBandPlayerSDK
//
//  Created by Yogev Barber on 07/02/2018.
//  Copyright © 2018 IBand. All rights reserved.
//

#import "IBandPoll.h"

@class IBandSDK;

@interface IBandPoll (Internal)
-(IBandSDK*) getSDK;
@end

